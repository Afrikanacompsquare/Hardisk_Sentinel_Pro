================================================================================
|     __________             .___.______  _______  _______ ____                |
|     \______   \_____     __| _/|__\   \/  /\   \/  /_   /_   |               |
|      |       _/\__  \   / __ | |  |\     /  \     / |   ||   |               |
|      |    |   \ / __ \_/ /_/ | |  |/     \  /     \ |   ||   |               |
|      |____|_  /(____  /\____ | |__/___/\  \/___/\  \|___||___|               |
|             \/      \/      \/          \_/      \_/           [ 2019 ]      |
+------------------------------------------------------------------------------+

==[ RELEASE INFO ]==============================================================
|                                                                              |
| > Name......: HD Sentinel 5.x PRO Activator                                  |
| > Date......: 2019-03-13                                                     |
| > Version...: 1.1                                                            |
| > File......: Activator.exe                                                  |
| > MD5.......: deb25d06d1e4094a2f45dea644bb1b22                               |
| > SHA1......: a9af1858036613b979db2bb86a1a70b4a236010a                       |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET INFO ]===============================================================
|                                                                              |
| > Category..: Hard Disk Utilities                                            |
| > Protection: License File/Custom                                            |
| > OS........: WinALL                                                         |
| > Homepage..: https://www.hdsentinel.com                                     |
|                                                                              |
+------------------------------------------------------------------------------+

==[ TARGET DESCRIPTION ]========================================================
|                                                                              |
| Hard Disk Sentinel (HDSentinel) is a multi-OS SSD and HDD monitoring and     |
| analysis software. Its goal is to find, test, diagnose and repair hard disk  |
| drive problems, report and display SSD and HDD health, performance           |
| degradations and failures. Hard Disk Sentinel gives complete textual         |
| description, tips and displays/reports the most comprehensive information    |
| about the hard disks and solid state disks inside the computer and in        |
| external enclosures (USB hard disks / e-SATA hard disks). Many different     |
| alerts and report options are available to ensure maximum safety of your     |
| valuable data.                                                               |
|                                                                              |
+------------------------------------------------------------------------------+

==[ HOW TO USE ]================================================================
|                                                                              |
| Interactive Mode (Default)                                                   |
| ==========================                                                   |
|                                                                              |
| 1. Start the activator and complete all the required fields as desired.      |
|                                                                              |
| 2. To activate the currently installed program, click "Activate". NOTE: Make |
| sure to run the program at least once before activate it.                    |
|                                                                              |
| 3. To activate a portable version of the program, click the down arrow at    |
| the left side of "Activate" button, select "Portable" and then locate the    |
| folder that contains the program.                                            |
|                                                                              |
| Silent or Very Silent Mode                                                   |
| ==========================                                                   |
|                                                                              |
| Use the command line options described in "Command Line Parameters/Exit      |
| Codes" section.                                                              |
|                                                                              |
+------------------------------------------------------------------------------+

==[ COMMAND LINE PARAMETERS & EXIT CODES ]======================================
|                                                                              |
| Options (use "/" or "-")                                                     |
| ========================                                                     |
|                                                                              |
| /activateinstall:<path>                                                      |
|                                                                              |
| Performs a silent activation of the currently installed program, <path> is   |
| an optional path to the installation folder. When this path is not specified |
| , the program location is obtained following this sequence: current folder   |
| (where the activator is located), from the registry (if available), folder   |
| selection dialog (interactive and silent modes only). IMPORTANT: if path     |
| contains white spaces, enclose it in double quotes.                          |
|                                                                              |
| /activateportable:<path>                                                     |
|                                                                              |
| Performs a silent activation of a portable version of the program, <path>    |
| specifies the location of the program. When this path is not specified, the  |
| program location is obtained following this sequence: current folder (where  |
| the activator is located), folder selection dialog (interactive and silent   |
| modes only). IMPORTANT: if path contains white spaces, enclose it in double  |
| quotes.                                                                      |
|                                                                              |
| /expdate:<mm/dd/yyyy>                                                        |
|                                                                              |
| Specifies the expiration date for the license. Allowed dates starts from     |
| current date until 12/31/2050. If this option is not used (default), the     |
| license will not have expiration date (never expires).                       |
|                                                                              |
| /help or /?                                                                  |
|                                                                              |
| Shows a message box with a short description of the standard command line    |
| parameters.                                                                  |
|                                                                              |
| /numlic:<number>                                                             |
|                                                                              |
| Specifies the number of licenses to cover. Allowed values are 1 to 32767.    |
| Default value is 1.                                                          |
|                                                                              |
| /overwrite                                                                   |
|                                                                              |
| Overwrites any existing license file. By default, if a license file already  |
| exists, the activator will ask confirmation to overwrite it.                 |
|                                                                              |
| /regname:<name>                                                              |
|                                                                              |
| Specifies the registration name to use. The current user name is used by     |
| default. IMPORTANT: if name contains white spaces, enclose it in double      |
| quotes.                                                                      |
|                                                                              |
| /verysilent                                                                  |
|                                                                              |
| Performs a very silent activation. It does not show any dialog or message    |
| box.                                                                         |
|                                                                              |
| Exit Codes                                                                   |
| ==========                                                                   |
|                                                                              |
| 0: No error (nothing done).                                                  |
|                                                                              |
| 1: Integrity error, activator executable was modified or is corrupted.       |
|                                                                              |
| 2: Activator is already running.                                             |
|                                                                              |
| 3: Administrative privileges are required (actually not used, the activator  |
| already requests for elevation when executed).                               |
|                                                                              |
| 4: A fatal error has occurred and cannot continue.                           |
|                                                                              |
| 5: Activation succeeded.                                                     |
|                                                                              |
| 6: Activation failed.                                                        |
|                                                                              |
| 7: Activation aborted.                                                       |
|                                                                              |
| 8: Invalid registration name length.                                         |
|                                                                              |
| 9: Invalid number of licenses.                                               |
|                                                                              |
| 10: Invalid expiration date.                                                 |
|                                                                              |
| 11: Program location not found (very silent mode only).                      |
|                                                                              |
| 12: License file already exists (very silent mode only and if /overwrite     |
| option was not used).                                                        |
|                                                                              |
+------------------------------------------------------------------------------+

==[ UPDATES & FIXES ]===========================================================
|                                                                              |
| To get the most recent version of this release, go to Options menu (little   |
| button with a down arrow at top-right corner) -> "Check for updates" or just |
| visit the site listed at the end (recommended).                              |
|                                                                              |
+------------------------------------------------------------------------------+

==[ FOR EVALUATION PURPOSES ONLY ]==============================================
|                                                                              |
| If you can afford it, please BUY IT. Support the developer to make a better  |
| product.                                                                     |
|                                                                              |
+------------------------------------------------------------------------------+

==[ RELEASES & SOURCE CODES ]===================================================
|                                                                              |
| https://radixx11rce2.blogspot.com                                            |
|                                                                              |
+------------------------------------------------------------------------------+
